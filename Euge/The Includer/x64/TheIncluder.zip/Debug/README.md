﻿# The Includer 
**[Integrantes:]**
------------------------------

**AYALA, Elizabeth C.**

**QUINTEROS, David**

**AREVALO, R. Eugenio**

------------------------------

------------
The Includer: 
------------
En un rincón muy lejano de este basto mundo, existe un ser llamado Includer, 
que luchará contra las adversidades y restricciones que sufren los habitantes del lugar.
En la Búsqueda de un mundo mejor, y más equitativo para tod@s, The Includer, 
tomará lo peor de éste y lo transformará en herramientas para mejorar el día a día de tod@s los seres.
 

